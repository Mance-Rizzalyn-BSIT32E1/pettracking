<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/output.css">
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="/css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            display: flex;
            flex-direction: row;
            background-color: #CBE2B5;
            margin: 0;
            padding: 0;
        }

        #sidebar {
            width: 20%;
            height: 100vh;
            background-color: white;
        }

        #content {
            flex-grow: 1;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            position: relative;
            box-sizing: border-box;
        }

        @media (max-width: 700px) {
            span {
                display: none;
            }

            #sidebar {
                width: 10%;
            }

            #content {
                padding: 2px;
                flex-direction: column;
                justify-content: center;
                align-items: center;
            }
        }
    </style>
    <title>Main Dashboard</title>
</head>

<body>
    <div id="sidebar">
        <?php include('./sidebar-1.php'); ?>
    </div>
    <div id="content">
        <?php include('./BarGraph.php') ?>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="./javascript/sessionmessage.js"></script>
    <script src="./javascript/active.js"></script>
</body>

</html>
