<?php
require 'database_connection.php'; // Include your database connection

$type = $_POST['type'];

if ($type === 'geofence') {
    $sessionId = $_POST['session_id'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $radius = $_POST['radius'];

    // Prepare the SQL statement
    $stmt = $pdo->prepare("INSERT INTO geofences (session_id, latitude, longitude, radius) VALUES (?, ?, ?, ?)");
    $stmt->execute([$sessionId, $latitude, $longitude, $radius]);
    
    // Optional: return a success message
    echo json_encode(['status' => 'success']);
}
?>
