<?php
// Include database connection
include 'db_connection.php'; // Make sure to create this file to establish a DB connection

// Check if session ID is provided
if (isset($_GET['session_id'])) {
    $sessionId = $_GET['session_id'];

    // Prepare the SQL query
    $query = "SELECT latitude, longitude, radius FROM geofences WHERE session_id = ?";
    
    // Create a prepared statement
    if ($stmt = $conn->prepare($query)) {
        // Bind the session ID parameter
        $stmt->bind_param("s", $sessionId);
        
        // Execute the query
        $stmt->execute();
        
        // Get the result
        $result = $stmt->get_result();
        
        // Fetch all geofences as an associative array
        $geofences = [];
        while ($row = $result->fetch_assoc()) {
            $geofences[] = $row;
        }
        
        // Return the geofences as JSON
        header('Content-Type: application/json');
        echo json_encode($geofences);
        
        // Close the statement
        $stmt->close();
    } else {
        // Handle query preparation error
        echo json_encode(["error" => "Query preparation failed."]);
    }
} else {
    // Handle case when session_id is not provided
    echo json_encode(["error" => "Session ID not provided."]);
}

// Close the database connection
$conn->close();
?>
