<?php
session_start();
set_time_limit(120);

$registeredPets = isset($_SESSION["registeredPets"]) ? $_SESSION["registeredPets"] : [];

// Pick a random icon for each pet marker
function getRandomIcon() {
    $icons = [
        'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
        'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
        'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png'
    ];
    return $icons[array_rand($icons)];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Leaflet Map with Clickable Markers, Geofencing, and Search</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Include CSS files -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" />
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/output.css">
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="/css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0px;
            position: relative;
            background-color: #CBE2B5;
        }


    .h-auto.w-full.flex.items-center.justify-end {
    justify-content: center; /* Center horizontally */
}

.dt {
    font-size: 20px;
    position: fixed;
    color: #343131;
    padding: 20px 20px;
    border-radius: 5px;
    border: 1px solid black;
    background-color: transparent;
    margin: 30px;
    text-align: center; /* Center the text inside the element */
}

@media (max-width: 700px) {
    .dt {
        font-size: 14px;
        padding: 10px 10px;
    }
            #sidebar {
                width: 10%;
                /* Adjust width as needed */
                height: 100vh;
                /* Full height */
                background-color: white;
                /* Sidebar background color */
            }
        }

        .col2 {
            background-color: blue;
            width: 100vw;
        }

        .container2  {
            display: flex;
            flex-direction: row;
        }

        .date-time {
    background-color: transparent; /* Makes the background transparent */
    border: 1px solid black; /* Adds a black border */
    height: 5rem; /* Sets the height of the element */
}
#search-container { 
    position: absolute;
    top: 70px; /* Adjusted position from top */
    left: 1%; /* Margin left at 1% */
    z-index: 1000;
    display: flex; /* Flexbox for better alignment */
    align-items: center; /* Center items vertically */
    transition: box-shadow 0.3s; /* Transition for shadow */
}

#search-input {
    width: 350px; /* Width of the input */
    padding: 12px 40px; /* Increased padding for comfort and space for the icon */
    border: 1px solid #ddd; /* Light grey border */
    border-radius: 10px; /* Rounded corners */
    font-size: 16px; /* Font size */
    transition: border 0.3s, box-shadow 0.3s; /* Smooth transition for border change */
    background-color: #ffffff; /* White background for the input */
    position: relative; /* To position the icon inside */
}

#search-input:focus {
    border: 1px solid #4285f4; /* Highlight border on focus */
    outline: none; /* Remove default outline */
    box-shadow: 0 0 8px rgba(66, 133, 244, 0.4); /* Subtle glow effect */
}

#search-icon {
    position: absolute; /* Positioning the icon inside the input */
    left: 10px; /* Positioning from the left */
    top: 50%; /* Center vertically */
    transform: translateY(-50%); /* Adjust vertical position */
    color: #aaa; /* Icon color */
}

#suggestions {
    position: absolute;
    top: 100%; /* Position suggestions directly below the input */
    left: 0; /* Align with the left of the input */
    background: #ffffff; /* White background for suggestions */
    border: 1px solid #ddd; /* Light border for suggestions */
    border-radius: 4px; /* Slightly rounded corners */
    width: 350px; /* Match width of the input */
    max-height: 200px; /* Max height for suggestions */
    overflow-y: auto; /* Scrollable if too many suggestions */
    z-index: 999; /* Layering */
    display: none; /* Hidden by default */
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); /* Light shadow for suggestions */
}

.suggestion-item {
    padding: 12px 16px; /* Increased padding for better clickability */
    cursor: pointer; /* Pointer cursor for suggestions */
    transition: background-color 0.3s, padding 0.2s; /* Smooth transition for hover effect */
}

.suggestion-item:hover {
    background-color: #f1f1f1; /* Highlight on hover */
    padding-left: 20px; /* Slight padding shift for hover */
}



        #sidebar {
            width: 20%; /* Adjust width as needed */
            height: 100vh; /* Full height */
            background-color: white; /* Sidebar background color */
        }
        #logo {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            height: 100%;
            object-fit: contain;
            opacity: 0.4;
            z-index: 0;
        }

        @media (max-width: 700px) {
            
            span {
                display: none;
            }

            #sidebar {
                width: 10%;
                /* Adjust width as needed */
                height: 100vh;
                /* Full height */
                background-color: white;
                /* Sidebar background colo  r */
            }
        }

    </style>
</head>
<body>
    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 size-full relative">
            <div class="grid grid-rows-7 h-full">
                <div class="h-auto w-full flex items-center justify-end">
                    <div id="datetime" class="dt"></div>
                    <div id="search-container" class="relative">
                        <input type="text" id="search-input" placeholder="Search Address..." />
                        <span id="search-icon">&#x1F50D;</span>
                        <div id="suggestions"></div>
                    </div>
                </div>
                <div id="map" class="row-span-6"></div>
            </div>
        </div>
    </div>

    <!-- Include JavaScript files -->
    <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js"></script>
    <script>
        var map = L.map('map').setView([51.505, -0.09], 13);

        // Adding different base layers
        var osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; OpenStreetMap contributors'
        });

        var googleLayer = L.tileLayer('https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
            maxZoom: 20,
            subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
            attribution: '&copy; Google Maps'
        });

        // Add OSM as default layer
        osmLayer.addTo(map);

        // Layer control
        var baseMaps = {
            "OpenStreetMap": osmLayer,
            "Google Maps": googleLayer
        };
        L.control.layers(baseMaps).addTo(map);

        var ownerMarker = null;
        var ownerGeofence = null;
        var geofenceRadius = 36; // radius in meters
        var petMarkers = [];

        // Set geofence function
        function setGeofence(lat, lng) {
            alert("Location: " + lat + ", " + lng);
            if (ownerGeofence) {
                map.removeLayer(ownerGeofence);
            }
            ownerGeofence = L.circle([lat, lng], {
                radius: geofenceRadius,
                color: 'red',
                fillColor: '#f03',
                fillOpacity: 0.5
            }).addTo(map);
        }

        // Update location function
        function updateLocation(position) {
            var lat = position.coords.latitude;
            var lng = position.coords.longitude;

            if (ownerMarker) {
                ownerMarker.setLatLng([lat, lng]);
            } else {
                ownerMarker = L.marker([lat, lng]).addTo(map)
                    .bindPopup('Owner').openPopup();
            }

            map.setView([lat, lng], 13);
        }

        function handleLocationError(error) {
            alert('Error: ' + error.message);
        }

        if (navigator.geolocation) {
            navigator.geolocation.watchPosition(updateLocation, handleLocationError, {
                enableHighAccuracy: true,
                timeout: 5000,
                maximumAge: 0
            });
        } else {
            alert('Geolocation is not supported by your browser.');
        }

        // Search functionality
        var suggestions = document.getElementById('suggestions');
        document.getElementById('search-input').addEventListener('input', function() {
    var searchInput = this.value;
    if (searchInput) {
        fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchInput)}`)
            .then(response => response.json())
            .then(data => {
                suggestions.innerHTML = '';  // Clear previous suggestions
                if (data.length > 0) {
                    suggestions.style.display = 'block';  // Show suggestions
                    data.forEach(item => {
                        var suggestionItem = document.createElement('div');
                        suggestionItem.classList.add('suggestion-item');
                        suggestionItem.textContent = item.display_name;
                        suggestionItem.onclick = function() {
                            selectLocation(item);  // Call location selection function
                        };
                        suggestions.appendChild(suggestionItem);
                    });
                } else {
                    suggestions.style.display = 'none';  // Hide if no data found
                }
            })
            .catch(error => {
                console.error('Error fetching location:', error);
                suggestions.style.display = 'none';  // Hide on error
            });
    } else {
        suggestions.style.display = 'none';  // Hide if input is empty
    }
});

        // Function to handle selection of a location
        function selectLocation(item) {
            var lat = parseFloat(item.lat);
            var lng = parseFloat(item.lon);

            map.setView([lat, lng], 15); // Zoom into the selected location
            suggestions.style.display = 'none';

            // Display a marker at the selected location
            var logoPin = L.marker([lat, lng], {
                icon: L.icon({
                    iconUrl: 'path/to/your/logo.png', // Replace with your logo path
                    iconSize: [40, 40] // Adjust the size of the logo pin
                })
            }).addTo(map);

            // Optional: Add popup
            logoPin.bindPopup(`You searched for: ${item.display_name}`).openPopup();

            // Ask the user if they want to set a geofence or pin a pet
            if (confirm("Do you want to set a geofence or pin your pet at this location?")) {
                var action = prompt("Type 'geofence' to set a geofence or 'pin' to pin the pet:");

                if (action.toLowerCase() === 'geofence') {
                    setGeofence(lat, lng);
                } else if (action.toLowerCase() === 'pin') {
                    // Logic to pin the pet
                    if (!isPetRegistered()) {
                        alert('Please register a pet before adding markers.');
                        window.location.href = 'pet-registration.php';
                        return;
                    }
                    if (!isInsideGeofence(lat, lng)) {
                        alert('You can only pin a pet inside the geofence.');
                        return;
                    }
                    var registeredPetNames = getRegisteredPetNames();
                    var name = prompt('Enter pet name:');
                    if (name && registeredPetNames.includes(name)) {
                        addMarker(lat, lng, name);
                        alert("Pet pinned at location: " + lat + ", " + lng);
                    } else {
                        alert('Invalid pet name. Please enter a registered pet name.');
                    }
                } else {
                    alert("Invalid action. Please type 'geofence' or 'pin'.");
                }
            }
        }

        // Function to check if a point is inside the geofence
        function isInsideGeofence(lat, lng) {
            if (!ownerGeofence) {
                return false;
            }
            var geofenceCenter = ownerGeofence.getLatLng();
            var distance = map.distance(geofenceCenter, L.latLng(lat, lng));
            return distance <= geofenceRadius;
        }

        // Function to check if a pet is registered
        function isPetRegistered() {
            return <?php echo json_encode(count($registeredPets) > 0); ?>;
        }

        // Function to get registered pet names
        function getRegisteredPetNames() {
            var names = <?php echo json_encode(array_column($registeredPets, 'petName')); ?>;
            return names;
        }

        // Function to add a pet marker
        function addMarker(lat, lng, name) {
            var marker = L.marker([lat, lng], { icon: getRandomIconUrl() }).addTo(map)
                .bindPopup(name);

            var pet = {
                name: name,
                marker: marker
            };
            petMarkers.push(pet);

            // Send data to history.php
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "history.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.send("lat=" + lat + "&lng=" + lng + "&name=" + name + "&timestamp=" + new Date().toISOString());
        }

        // Function to get a random icon for the marker
        function getRandomIconUrl() {
            var randomIcon = icons[Math.floor(Math.random() * icons.length)];
            return L.icon({
                iconUrl: randomIcon.iconUrl,
                iconSize: randomIcon.iconSize,
                iconAnchor: randomIcon.iconAnchor,
                popupAnchor: randomIcon.popupAnchor
            });
        }

        var icons = [
            {
                iconUrl: './icon/gps.png',
                iconSize: [30, 40],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34]
            },
            {
                iconUrl: './icon/location.png',
                iconSize: [30, 40],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34]
            },
            {
                iconUrl: './icon/map.png',
                iconSize: [30, 40],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34]
            }
        ];

        // Function to update date and time
        function updateDateTime() {
            var now = new Date();
            var options = {
                timeZone: 'Asia/Manila',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            };
            var formatter = new Intl.DateTimeFormat([], options);
            document.getElementById('datetime').innerHTML = formatter.format(now);
        }

        setInterval(updateDateTime, 1000); // Update every second
        updateDateTime(); // Initial call to display immediately

        // Remove unnecessary duplicate tile layer addition
        // L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);

    </script>
</body>
</html>
