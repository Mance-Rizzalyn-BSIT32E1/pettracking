<?php
session_start(); // Start the session
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sticky Notes</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            background-color: #CBE2B5;
        }

        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
        }

        .form-control {
            border: 1px solid #ced4da;
            border-radius: 8px;
            padding: 10px;
            font-size: 18px;
            background-color: #fff;
            width: calc(100% - 20px);
            box-sizing: border-box;
            margin-bottom: 10px;
        }

        .btn-primary {
            border: none;
            padding: 5px 12px; /* Reduced padding for smaller width */
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px; /* Slightly smaller font size */
            transition: background-color 0.3s ease;
            margin-right: -300px;
            width: 80px; /* Reduced button width */
            text-align: center;
        }

        .btn-primary {
            background-color: #88c9f8;
            color: #fff;
        }

        .btn-primary:hover {
            background-color: #5cb3e6;
        }

        .search-bar {
            margin: 20px 0;
            display: flex;
            align-items: center;
        }

        .search-bar input {
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #ced4da;
            width: 100%;
            max-width: 300px;
            font-size: 16px;
            margin-left: 10px;
        }

        #typingSection {
            margin-top: 20px;
        }

        #typingSection textarea {
            width: 100%;
            resize: vertical;
        }

        /* Flex container for buttons */
        .button-group {
            display: flex;
            justify-content: flex-end;
            gap: 10px; /* Space between buttons */
            margin-top: 10px; /* Space above the button group */
        }

        #notes {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    gap: 10px;
    margin-top: 20px;
    margin-left: 20px; /* Add margin from the sidebar */
    margin-right: 20px; /* Optional: Add right margin for balance */
    max-width: calc(100% - 150px); /* Adjust width according to the margin */
    overflow-y: auto;
    max-height: 400px;
}

.note-item {
    background-color: #c8e6c9;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    padding: 15px;
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    text-align: left;
    transition: background-color 0.3s;
    height: 150px; /* Fixed height for sticky note effect */
    max-height: 150px; /* Ensure a fixed maximum height */
    overflow: hidden; /* Hide overflow content */
    margin-left: auto; /* Center note-item within its container */
    margin-right: auto; /* Center note-item within its container */
}

.note-content {
    font-size: 1em;
    margin: 10px 0;
    word-wrap: break-word;
    max-height: 80px; /* Allow scroll if content exceeds */
    overflow-y: auto;
    overflow-x: hidden;
    flex-grow: 1;
    cursor: text; /* Indicates that the content is editable */
    padding-right: 30px; /* Add padding to the right */
}


        .delete-note {
            position: absolute;
            bottom: 10px;
            right: 15px;
            font-size: 14px;
            background: transparent;
            border: none;
            cursor: pointer;
            color: #e74c3c;
        }

        .delete-note:hover {
            color: #c0392b;
        }

        #sidebar {
            width: 20%;
            height: 100vh;
            background-color: white;
        }
        .button-container {
    display: flex;
    justify-content: flex-start; /* Align buttons to the left */
    gap: 10px; /* Adds space between the buttons */
}

button {
    padding: 10px 20px; /* Example padding for buttons */
    margin-top: 10px;
    font-size: 16px;
    cursor: pointer;
}

#actionBtn {
    background-color: #4CAF50; /* Green for save */
    color: white;
    top: -200px;
}

#cancelBtn {
    background-color: #f44336; /* Red for cancel */
    color: white;
    top: -200px;
}

        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }

            .search-bar input {
                width: 100%;
                margin-left: 0; /* Remove left margin on small screens */
                margin-top: 10px; /* Add top margin for spacing */
            }

            #sidebar {
                width: 10%;
            }

            /* Stack buttons vertically on small screens if needed */
            .button-group {
                flex-direction: column;
                align-items: stretch;
            }

            .btn-primary {
                width: 100%; /* Full width buttons on small screens */
                margin-right: 0; /* Remove right margin */
            }
        }

        #no-notes {
            display: none;
            font-size: 18px;
            color: #888;
            text-align: center;
            margin-top: 20px;
        }

        .separator {
            border: none;
            border-top: 1px solid #ccc;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 relative">
            <div class="container">
                <div class="search-bar">
                    <button id="toggleTyping" class="btn-primary">+</button>
                    <input type="text" id="searchTxt" class="form-control" placeholder="Search notes...">
                </div>
                <div id="typingSection" class="hidden">
                    <textarea id="addTxt" class="form-control" rows="2" placeholder="Type your note here..."></textarea>
                    <div class="button-group">
                    
    <button id="actionBtn">Save</button>
    <button id="cancelBtn">Cancel</button>
</div>

                    </div>
                </div>
                <hr class="separator">
                <div id="notes">
                    <!-- Notes will be dynamically inserted here -->
                </div>
                <div id="no-notes">No Notes</div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        loadNotes();

        document.getElementById('toggleTyping').addEventListener('click', function () {
            toggleTypingSection();
        });

        document.getElementById('actionBtn').addEventListener('click', function () {
            var noteContent = document.getElementById('addTxt').value;
            if (noteContent.trim()) {
                var dateTime = new Date().toLocaleString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'numeric',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                });
                addNoteToList(noteContent, dateTime);
                saveNoteToLocalStorage(noteContent, dateTime);
                document.getElementById('addTxt').value = '';
                toggleTypingSection();
            }
        });

        document.getElementById('cancelBtn').addEventListener('click', function () {
            toggleTypingSection();
            document.getElementById('addTxt').value = ''; // Clear the input field when canceling
        });

        document.getElementById('searchTxt').addEventListener('input', function () {
            filterNotes(this.value);
        });
    });

    function toggleTypingSection() {
        var typingSection = document.getElementById('typingSection');
        typingSection.classList.toggle('hidden');
        var actionBtn = document.getElementById('actionBtn');
        if (!typingSection.classList.contains('hidden')) {
            actionBtn.textContent = 'Save';
            actionBtn.setAttribute('data-editing', 'false');
        }
    }

    function addNoteToList(noteContent, dateTime) {
        var notesContainer = document.getElementById('notes');
        var noteItem = document.createElement('div');
        noteItem.className = 'note-item';
        noteItem.setAttribute('data-content', noteContent);

        noteItem.innerHTML = `
            <div class="note-header">
                <span>${dateTime}</span>
            </div>
            <div class="note-content" contenteditable="false">${noteContent}</div>
            <button class="delete-note"><i class="fas fa-trash-alt"></i></button>
        `;

        notesContainer.appendChild(noteItem);

        noteItem.querySelector('.note-content').addEventListener('dblclick', function () {
            this.setAttribute('contenteditable', 'true');
            this.focus();
        });

        noteItem.querySelector('.note-content').addEventListener('blur', function () {
            this.setAttribute('contenteditable', 'false');
            var updatedDateTime = new Date().toLocaleString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'numeric',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
            });
            var updatedContent = this.textContent.trim();
            noteItem.setAttribute('data-content', updatedContent);
            noteItem.querySelector('.note-header span').textContent = updatedDateTime;
            saveNotes();
        });

        noteItem.querySelector('.delete-note').addEventListener('click', function () {
            notesContainer.removeChild(noteItem);
            saveNotes();
        });

        saveNotes();
    }

    function saveNoteToLocalStorage(noteContent, dateTime) {
        var notes = JSON.parse(localStorage.getItem('notes')) || [];
        notes.push({ content: noteContent, dateTime: dateTime });
        localStorage.setItem('notes', JSON.stringify(notes));
        updateNoNotesMessage();
    }

    function loadNotes() {
        var notes = JSON.parse(localStorage.getItem('notes')) || [];
        notes.forEach(function(note) {
            addNoteToList(note.content, note.dateTime);
        });
    }

    function saveNotes() {
        var notesContainer = document.getElementById('notes');
        var notes = [];
        Array.from(notesContainer.children).forEach(function(noteItem) {
            notes.push({
                content: noteItem.getAttribute('data-content'),
                dateTime: noteItem.querySelector('.note-header span').textContent
            });
        });
        localStorage.setItem('notes', JSON.stringify(notes));
        updateNoNotesMessage();
    }

    function filterNotes(query) {
        var notes = document.querySelectorAll('.note-item');
        notes.forEach(function (note) {
            var content = note.getAttribute('data-content');
            if (content.toLowerCase().includes(query.toLowerCase())) {
                note.style.display = '';
            } else {
                note.style.display = 'none';
            }
        });
        updateNoNotesMessage();
    }

    function updateNoNotesMessage() {
        var notes = JSON.parse(localStorage.getItem('notes')) || [];
        var noNotesMessage = document.getElementById('no-notes');
        if (notes.length === 0) {
            noNotesMessage.style.display = 'block';
        } else {
            noNotesMessage.style.display = 'none';
        }
    }
    </script>
</body>
</html>
