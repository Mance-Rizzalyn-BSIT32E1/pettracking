<style>
/* Importing a Google Font for a systematic look */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

/* Enhanced Sidebar background, border, and shadow */
#sidebar {
    background: #ffffff;
    border-right: 1px solid #ccc;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    font-family: 'Poppins', sans-serif;

    
}

/* Profile section */
#profile {
    border-bottom: 1px solid #ccc;
    padding: 20px 0;
    text-align: center;
}

/* Profile image */
#profile img {
    width: 90px;
    border: 3px solid #17B890;
    padding: 5px;
    border-radius: 50%;
    margin: 10px auto;
}

/* Profile name and role */
#profile h2 {
    font-size: 20px;
    color: #333;
    margin-top: 10px;
    font-weight: 600;
}

#profile p {
    color: #777;
    margin-bottom: 10px;
}

/* Menu container styling */
#menu {
    margin-top: 20px;
    padding: 10px;
}

#menu a {
    display: flex;
    align-items: center;
    padding: 15px 20px; /* Increased padding */
    border-radius: 10px; /* More rounded corners */
    color: #333;
    font-size: 18px; /* Increased font size */
    font-weight: 600; /* Bold font */
    transition: all 0.3s ease;
}

#menu a:hover {
    background-color: #17B890;
    color: white;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transform: translateX(4px);
}

#menu svg {
    margin-right: 16px; /* Increased margin for better spacing */
    width: 24px; /* Increased icon size */
    height: 24px; /* Increased icon size */
    transition: fill 0.3s ease;
}

#menu a:hover svg {
    fill: white;
}

/* Logout button */
button {
    background: #f8f9fa;
    border: 1px solid #ccc;
    border-radius: 8px;
    color: #495057;
    font-size: 16px;
    font-weight: 600; /* Semi-bold */
    padding: 10px 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 190px auto 20px; /* Use a negative margin-top to overlap */
    width: 90%;
    transition: background-color 0.3s ease, color 0.3s ease;
    position: relative; /* Make sure the button is positioned relative */
    z-index: 1; /* Bring the button above other elements */
}


button:hover {
    background-color: #982B1C;
    color: white;
    transform: translateX(2px);
}

button svg {
    margin-right: 10px; /* Increased margin for icon */
    width: 20px; /* Adjusted icon size */
    height: 20px; /* Adjusted icon size */
    transition: fill 0.3s ease;
}

button:hover svg {
    fill: white;
}

/* Divider for sections */
.section-divider {
    border-bottom: 1px solid #ccc;
    margin: 20px 0;
}
</style>



<body class="font-poppins antialiased">
    <div id="view" class="h-full w-screen flex flex-row">
        <div id="sidebar" class="h-screen shadow-xl px-8 w-30 md:w-60 lg:w-80 overflow-x-hidden">
            <div id="profile">
                <img src="user/images/logo.png" alt="Avatar user" />
                <h2><?php echo $_SESSION['user_name']; ?></h2>
                <p>Owner</p>
            </div>
            
            <div id="menu" class="flex flex-col space-y-3">
                <a href="./pet-registration.php">
                    <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M12 2a4 4 0 014 4v1h-2V6a2 2 0 00-2-2H8a2 2 0 00-2 2v1H4V6a4 4 0 014-4h4z"></path>
                        <path fill-rule="evenodd" d="M4 10v7h12v-7H4zm3-3h6v3H7V7z" clip-rule="evenodd"></path>
                    </svg>
                    <span>Pets</span>
                </a>
                <a href="./map.php">
                    <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M17 8a5 5 0 10-10 0 5 5 0 0010 0zM7.293 9.293a1 1 0 011.414 0L10 10.586V17h2v-6.414l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z"></path>
                    </svg>
                    <span>Map</span>
                </a>
                <a href="./history.php">
                    <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 2a8 8 0 100 16 8 8 0 000-16zM8 12a1 1 0 112-0V6a1 1 0 10-2 0v6z" clip-rule="evenodd"></path>
                    </svg>
                    <span>Pet Tracking Log</span>
                </a>
                <a href="./note.php">
                    <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V7a2 2 0 00-2-2h-5.586l-1-1H4zm1 9h10V5H5v7z" clip-rule="evenodd"></path>
                    </svg>
                    <span>Notes</span>
                </a>
                <a href="./user/update_profile.php">
                    <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 12a6 6 0 100-12 6 6 0 000 12zM2 18a8 8 0 0116 0H2z" clip-rule="evenodd"></path>
                    </svg>
                    <span>Profile</span>
                </a>
            </div>

            <div class="section-divider"></div>

            <div>
    <form action="../index.php" method="post">
        <button type="submit" class="flex flex-row w-full text-lg font-medium text-gray-700 py-3 px-2 hover:bg-teal-500 hover:text-white hover:scale-105 rounded-md transition duration-150 ease-in-out items-end justify-start">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 fill-current inline-block">
                <path d="M16 13v-2H7V8l-5 4 5 4v-3z"></path>
                <path d="M20 3h-9c-1.103 0-2 .897-2 2v4h2V5h9v14h-9v-4H9v4c0 1.103.897 2 2 2h9c1.103 0 2-.897 2-2V5c0-1.103-.897-2-2-2z"></path>
            </svg>
            <span>Logout</span>
        </button>
    </form>
</div>

        </div>
    </div>
</body>
