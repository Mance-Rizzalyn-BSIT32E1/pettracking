<?php
session_start();
include 'config.php';
 
if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = mysqli_real_escape_string($conn, md5($_POST['password']));
 
    $select = mysqli_query($conn, "SELECT * FROM user_form WHERE email = '$email' AND password = '$pass'") or die('Query failed: ' . mysqli_error($conn));
 
    if (mysqli_num_rows($select) > 0) {
        $row = mysqli_fetch_assoc($select);
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['user_name'] = $row['name'];
        header('Location: ../MainDashboard.php');
        exit;
    } else {
        $message[] = 'Invalid email or password!';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login | Pet Tracker</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
   <style>
      body {
         display: flex;
         flex-direction: column;
         justify-content: center;
         align-items: center;
         min-height: 100vh;
         margin: 0;
         padding: 0;
         font-family: 'Poppins', sans-serif;
         background-color: #f4f4f4;
         color: #333;
      }
      .logo-container {
   position: absolute;
   top: 100px; /* Adjust this value to control the distance from the top */
   left: 0;
   right: 0;
   text-align: center;
   margin: auto;
}

      /* Logo using Font Awesome icon */
      .logo-container i {
         font-size: 50px;
         color: #17b890;
      }

      .form-container {
         width: 100%;
         max-width: 450px; 
         background: #ffffff;
         border-radius: 15px;
         box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
         padding: 40px;
         text-align: center;
      }

      .form-container h3 {
         font-size: 24px;
         font-weight: 600;
         margin-bottom: 30px;
         color: #333;
      }

      .input-container {
         position: relative;
         width: 95%;
         margin-bottom: 20px;
      }

      .input-box {
         width: 100%;
         padding: 10px;
         padding-top: 30px; /* Ensures space for the label */
         border: 2px solid #333;
         border-radius: 5px;
         font-size: 20px;
         transition: border-color 0.3s ease;
      }

      .input-box:focus {
         border-color: #17b890;
         outline: none;
      }

      .input-box:hover {
         border-color: #17b890;
      }

      .input-label {
         position: absolute;
         top: -20px;
         left: 10px;
         background-color: white;
         padding: 0 5px;
         font-size: 20px;
         color: #333;
         transform: translateY(50%);
      }

      .btn {
         background-color: #17b890;
         color: #fff;
         padding: 12px;
         margin-top: 20px;
         width: 100%;
         height: 100%;
         border: none;
         border-radius: 10px;
         font-size: 25px;
         cursor: pointer;
         transition: background-color 0.3s ease;
      }

      .btn:hover {
         background-color: #128a6c;
      }

      p {
         margin-top: 20px;
         color: #666;
      }

      p a {
         color: #17b890;
         text-decoration: none;
      }

      p a:hover {
         text-decoration: underline;
      }

      .message {
         background: #f8d7da;
         color: #721c24;
         padding: 10px;
         margin-bottom: 20px;
         border-radius: 5px;
         border: 1px solid #f5c6cb;
      }
   </style>
</head>
<body>

<div class="logo-container">
   <i class="fas fa-paw"></i> <!-- Displaying a paw icon as the logo -->
</div>

<div class="form-container">
   <h3>Log in to Pet Tracker</h3>
   <?php
   if (isset($message)) {
      foreach ($message as $msg) {
         echo '<div class="message">'.$msg.'</div>';
      }
   }
   ?>
   <form action="" method="post">
      <div class="input-container">
         <label for="email" class="input-label">Email Address*</label>
         <input type="email" id="email" name="email" class="input-box">
      </div>
      <div class="input-container">
         <label for="password" class="input-label">Password*</label>
         <input type="password" id="password" name="password" class="input-box">
      </div>
      <input type="submit" name="submit" value="Log In" class="btn">
      <p>New to Pet Tracker? <a href="register.php">Create an account</a></p>
   </form>
</div>

</body>
</html>
